<template>
	<view>
		<view class="box" hover-class="boxHover">
			<scroll-view scroll-x class="scrollview" >
				<!-- scroll-x默认横向滑动，scroll-y表示默认纵向滑动 -->
				<view class="box">scroll子元素</view>
				<view class="box">scroll子元素</view>
				<view class="box">scroll子元素</view>
				<view class="box">scroll子元素</view>
				<view class="box">scroll子元素</view>
				<view class="box">scroll子元素</view>
				<view class="box">scroll子元素</view>
			</scroll-view>
		</view>
		
		<view class="">
<!-- 			<swiper :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000">
				<swiper-item>
					<view class="swiper-item"></view>
				</swiper-item>
				<swiper-item>
					<view class="swiper-item"></view>
				</swiper-item>
			</swiper> -->
			<!-- 拖动可轮播 -->
			<swiper indicator-dots="true" indicator-active-color="#b0e0e6" indicator-color="rgb(164,45,210,0.3)">
				<!--  indicator-active-color选中的点，indicator-color未选中的点-->
				<swiper-item>1111</swiper-item>
				<swiper-item>2222</swiper-item>
				<swiper-item>33333</swiper-item>
				<swiper-item>444444</swiper-item>
			</swiper>
		</view>
		<view>
			<button @click="open">打开弹窗</button>
			<uni-popup ref="popup" type="center" background-color="#fff" :animation="false">中间弹出 Popup</uni-popup>
		</view>
		<u-popup v-model="show">
			<view>出淤泥而不染，濯清涟而不妖</view>
		</u-popup>
		<u-button @click="show = true">打开</u-button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false
			}
		},
		methods: {
		    open(){
				// 通过组件定义的ref调用uni-popup方法 ,如果传入参数 ，type 属性将失效 ，仅支持 ['top','left','bottom','right','center']
		        this.$refs.popup.open('top')
		      }
			
		}
	}
</script>

<style lang="scss">
.scrollview{
	width: 80%;
	height: 220px;
	border:1px solid red;
	white-space: nowrap;  //表示不换行
	.box{
		width: 100px;
		height: 100px;
		background-color: cornflowerblue;
		display: inline-block; // 变成行级块元素
		margin: 5px;
	}
}

swiper{
	width: 100vw;
	// 100vw是整一个页面宽度的意思,50vw则是一半，vh就是页面的高度
	height: 200px;
	border: 1px solid green;
	swiper-item{
		width: 100%;
		height: 100%;
		background-color: pink;
	}
	//选择器
	swiper-item:nth-child(2n){
		background-color: orange;
	}
}

</style>
