<template>
	<view  class="beijing"> 
	<!-- 大背景 -->
		<view style="background-color: white; height: 850rpx; margin-top: 10px;">
			<!-- 白色背景板 -->
			<text class="xiu-ti">修改信息</text>
			<view style="margin-bottom: 20rpx;">
				<text class="xuanze">请选择是否发布该项目的资料修改</text>
			</view>
			<view class="dakuang" >
				<!-- label="自定义上传图标+指定上传按钮宽高" -->
				<view class="zidingyi">
					<text class="mingcheng">项目名称</text>
				</view>
				<view class="neirong">
					 <view class="xiu-nei">
					 	<text >修改内容</text>
					 </view>
					 <view class="xiu-nei">
					 	<text>修改前</text>
					 </view>
					 <view class="xiu-nei">
					 	<text>修改后</text>
					 </view>
					 <view class="">
					 	
					 </view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onShareAppMessage() {
		    return {};
		  },
		methods: {
			
		}
	}
</script>

<style scoped>
.beijing{
	background-color: #e6e6e6;
	width: 100vm;
	height:100vh;
}
.xiu-ti{
	font-size: 30rpx;
	margin-left: 40rpx;
},
.xuanze{
	font-size: 23rpx;
	margin-left: 30rpx;
	color: #ccc;
	// font-family: ;
}
.dakuang{
	width: 600rpx;
	height:550rpx;
	border-radius: 20rpx; 
	margin: auto;
	border: 1rpx
	solid #e6e6e6;
	align-items: center;
}
.zidingyi{
	background-color: #52a6ff; 
    border-top-left-radius: 20rpx;
    border-top-right-radius: 20rpx;
	width: 600rpx;
	height:100rpx;
	display: flex;
	position: relative;
	justify-content: center;

}
.mingcheng{
	font-size: 35rpx;
	color: #fff;
	/* font-weight: bold; */
	align-self: center;
}
.xiu-nei{
	font-size: 20rpx;
	margin-top: 50rpx;
	margin-left: 40rpx;
	margin-right: 40rpx;
	text-align: left;
	border-bottom:1px solid #e6e6e6;
}
.neirong{
	
}

</style>
