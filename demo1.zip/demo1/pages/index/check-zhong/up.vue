<template>
<view class="beijing">
		<view style="background-color: white; height: 800rpx; margin-top: 10px;">
			<text class="tianjia">添加附件</text>
			<view style="margin-bottom: 20rpx;">
				<text class="tupiangeshi">图片格式支持：jpg，png，jpeg</text>
			</view>
			<view class="dakuang" >
				<!-- label="自定义上传图标+指定上传按钮宽高" -->
				<view class="zidingyi">
					<text class="tupian">图片上传</text>
					<view class="item"  @tap="chooseImage">
						<uni-icons type="plus-filled" size="26" color="#fff"></uni-icons>
					</view>
				</view>
				<view class="shangchuan">
					 <image v-if="projectdoingpaperUrl" :src="projectdoingpaperUrl" mode="aspectFill" class="uploaded-img" />
				</view>
			</view>
			<view class="inputs">
				<view class="input-group">
						<text class="label" style="margin-right: 70rpx;">上传人</text>
						<span>
							<input class="input" v-model="paperUser" placeholder="   请输入上传人姓名"  />
						</span>
			    </view>
		
				<view class="input-group">
					<text class="label">上传时间</text>
					<span>
						<input class="input" v-model="paperTime" placeholder="   请选择或输入上传时间" />
					</span>
				</view>
			</view>
			<view class="bottom-box" >
				<button class="queren" @click="confirmUpload">确认上传</button>
				<!-- <uni-popup ref="popup" type="center" background-color="#ffff7f" :animation="false" borderRadius="40rpx" v-show="showPopup"> -->
				<uni-popup ref="popup" type="center":animation="false" borderRadius="40rpx" v-show="showPopup">
					<view class="tanchuang">
						{{ popupMessage }}
					</view>
					<view class="tanchu" @tap="closePopup">
						确认
					</view>
				</uni-popup>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// // 上传图片域名 
				projectdoingpaperUrl: '',
		        paperUser: '', // 上传人
		        paperTime: '', // 上传时间
		        projectdoinapaperId: '', // 图片ID
				showPopup: false, // 控制弹窗的显示
				popupMessage: '',// 初始化 popupMessage
				};
		},
		
		methods: {
			confirmUpload() {
			    // 检查数据是否齐全
			    if (
			        this.projectdoingpaperUrl &&
			        this.paperUser &&
			        this.paperTime &&
			        this.projectdoinapaperId
			    ) {
			        // 数据齐全，模拟发送数据到后台的操作（这里用 console.log 模拟）
			        const formData = {
			            projectdoinapaperId: this.projectdoinapaperId,
			            projectdoingpaperUrl: this.projectdoingpaperUrl,
			            paperUser: this.paperUser,
			            paperTime: this.paperTime,
			        };
			        console.log('上传数据到后台:', formData);
			
			        // 显示上传成功的弹窗，并清空数据
			        this.showPopup = true;
			        this.$refs.popup.open('center');
					this.popupMessage = '上传成功！'
			
			        // 清空数据
			        this.projectdoingpaperUrl = '';
			        this.paperUser = '';
			        this.paperTime = '';
			        this.projectdoinapaperId = '';
			    } else {
					this.showPopup = true;
					this.$refs.popup.open('center');
					this.popupMessage = '上传失败，数据不完整！'
			        // 数据不完整，弹出上传失败的弹窗
			    }
			},
		    closePopup() {
				// 关闭弹窗并清空数据
				this.showPopup = false;
		        this.projectdoingpaperUrl = '';
		        this.paperUser = '';
		        this.paperTime = '';
		      },
		  // 点击加号图标选择图片
		    chooseImage() {
		      uni.chooseImage({
		        count: 1, // 最多选择一张图片
		        sizeType: ['compressed'], // 压缩图片
		        sourceType: ['album'], // 从相册选择
		        success: (res) => {
					// 假设这里是获取图片ID的逻辑，可以根据实际情况修改
					this.projectdoinapaperId = '123'; // 假设将ID设置为固定值'123'
					this.projectdoingpaperUrl = res.tempFilePaths[0]; // 将选择的图片地址保存到 imageUrl
		        },
		      });
		    },
		}
	}
</script>

<style scoped>
.tupiangeshi{
	font-size: 23rpx;
	margin-left: 30rpx;
	color: #ccc;
	// font-family: ;
}

.tianjia{
	font-size: 30rpx;
	margin-left: 40rpx;
},
.beijing{
	background-color: #e6e6e6;
	width: 100%;
	height:2000rpx ;
},
/* .s-add-list-btn-icon {s
    font-size: 80rpx;
    height: 80rpx;
    line-height: 80rpx;
    margin-bottom: 20rpx;
    color: #999;
} */
.tupian{
	align-self: center;
	font-size: 30rpx;
	margin-left: 50rpx;
	color: #fff;
	font-weight: bold;
},
.dakuang{
	width: 680rpx;
	height:400rpx;
	border-radius: 20rpx; 
	margin: auto;
	border: 1rpx
	solid #e6e6e6;
	align-items: center;
}
.zidingyi{
	background-color: #5363E3; 
	/* margin: 15px; */
    border-top-left-radius: 20rpx;
    border-top-right-radius: 20rpx;
	width: 680rpx;
	height:100rpx;
	display: flex;
	position: relative;
	justify-content: space-between; 

},
.shangchuan{
	border: 10rpx;
	margin: 15rpx;
	height:280rpx;
	border: 1rpx ;
	display: flex;
	solid: #e6e6e6;
}
.add-icon {
    font-size: 16rpx; /* Adjust the icon size */
}
.upload-icon{
	position: absolute;
	right: 10rpx; 
	font-size: 16rpx;
	color: #fff; 
}
.item{
	margin-right: 20rpx;
	align-self: center;
	color: #fff;
}
.bottom-box {
    background-color: #5363E3;
	height: 125rpx;
	width: 100vw; 
	position: fixed;
	bottom: 0;
	
}
.queren{
	height: 125rpx;
	width: 100vw; 
	font-size: 30rpx;
	font-weight: bold;
	color: #fff;
	background-color: #5363E3;
	text-align: center;
    display: flex;
	justify-content: center;
	align-items: center;

}
.tanchuang{
	width: 425rpx; 
	height: 230rpx;
	/* border-radius: 40rpx; */
    border-top-left-radius: 40rpx;
    border-top-right-radius: 40rpx;
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;	
	text-align: center; 
	background-color: white;
    display: flex;
	justify-content: center;
	align-items: center;
	margin: auto;
}
.tanchu{
	height: 80rpx;
    display: flex;
	margin: auto;
    border-bottom-left-radius: 40rpx;
    border-bottom-right-radius: 40rpx;
	align-items: center;
	justify-content: center;
	border-top: 1px solid #e6e6e6;
	background-color: #5363E3 ;
	color: white;
}
.uploaded-img {
  width: 100%;
  height: 100%;
  border-radius: 20rpx;
}
.input-group {
  margin-bottom: 20rpx;
  display: flex;
  align-items: center;
}

.label {
	margin-left: 60rpx;
	margin-right: 40rpx;
  	margin-top: 30rpx;
	font-size: 28rpx;
	color: #333;
}
.input {
	width: 400rpx;
	height: 60rpx;
	margin-top: 30rpx;
	font-size: 28rpx;
	border: 1px solid #ececec;
	border-radius: 10rpx;
}
</style>
