<template>
  <div class="container">
    <!-- Top Box with Buttons -->
    <div class="top-box">
      <div class="button-group">
        <div class="dropdown" @click="toggleDropdown">
          <button class="dropbtn">{{ filter }}</button>
          <div class="dropdown-content" :class="{ 'show': dropdownOpen }">
            <a @click="filterProjects('全部项目')">全部项目</a>
            <a @click="filterProjects('未发布')">未发布</a>
            <a @click="filterProjects('已发布')">已发布</a>
          </div>
        </div>
      </div>
    </div>
    <!-- 项目列表 -->
    <div class="project-list">
      <div v-for="project in filteredProjects" :key="project.projectId" class="project-box">
        <img class="project-icon" src="https://ide.code.fun/api/image?token=668b58371a1c62001185f420&name=441270d68d2cba582aaf2b59e31a0aa0.png" alt="项目图标">
        <div class="project-info">
          <h3>{{ project.projectName }}</h3>
          <p :class="'project-output ' + getStatusClass(project.projectOutput)">{{ project.projectOutput }}</p>
        </div>
        <div class="buttons">
          <button v-if="isAdmin && project.projectOutput === '未发布'" @click="reviewProject(project)">审核</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
	
import axios from 'axios';
	
export default {
  data() {
    return {
      projects: [
        {
          projectId: 1,
          projectName: '绿色能源创新',
          projectOutput: '已发布'
        },
        {
          projectId: 2,
          projectName: '项目2',
          projectOutput: '已发布'
        },
        {
          projectId: 3,
          projectName: '项目3',
          projectOutput: '未发布'
        }
      ],
      showModal: false,
      selectedProject: null,
      filter: '全部项目',
      dropdownOpen: false
    };
  },
  computed: {
    isAdmin() {
      return true; // 假设所有人都是管理员
	},
    filteredProjects() {
      if (this.filter === '全部项目') {
        return this.projects;
      } else {
        return this.projects.filter(project => project.projectOutput === this.filter);
      }
    }
  },
  methods: {
    toggleDropdown() {
      this.dropdownOpen = !this.dropdownOpen;
    },
    filterProjects(projectOutput) {
      this.filter = projectOutput;
      this.dropdownOpen = true; 
    },
    // fetchProjects() {
    //   axios.get('http://192.168.75.1:8080/api/projects/projects/list') // 替换为实际的后端接口地址
    //     .then(response => {
		  // this.projects = response.data; // 假设后端返回的是项目数组
    //     })
    //     .catch(error => {
    //       console.error('获取项目失败:', error);
    //     });
    // },
	// async fetchProjects() {
	// 	try {
	// 	    const response = 
	// 	    this.projects = response.data;
	// 	  } catch (error) {
	// 	    console.error('获取项目时出错:', error);
	// 	    // 如果需要，处理特定的错误
	// 	    if (error.response) {
	// 	      // 请求已经发出，但服务器响应返回了状态码
	// 	      console.error('响应状态:', error.response.status);
	// 	    } else if (error.request) {
	// 	      // 请求已经发出，但未收到响应
	// 	      console.error('未收到响应:', error.request);
	// 	    } else {
	// 	      // 设置请求时发生了错误
	// 	      console.error('设置请求时出错:', error.message);
	// 	    }
	// 	  }
	//       // try {
	//       //   const response = await axios.get('http://192.168.112.1:8080/projects/projects/list')
	//       //   this.projects = response.data; // 假设后端返回的是项目数组
	//       // } catch (error) {
	//       //   console.error('Error fetching projects:', error);
	//       // }
	//     },
	// async reviewProject(project) {
	//       console.log('审核项目：', project.projectName);
	//       // 获取项目详情或者跳转到审核页面的逻辑
	//       this.$router.push({
	//         path: 'D:/大三小学期代码/demo1/pages/index/check-zhong', // 这里的路径需要根据你的实际路由配置来写
	//         query: { projectId: project.projectId }
	//       });
	//     },
   //  reviewProject(project) {
   //    console.log('审核项目：', project.projectName);
   //    // 跳转到审核页面的逻辑
	  // this.$router.push({
	  // 	  path:'./check-zhong',
	  // })
   //  },
    reviewProject(project) {
      // 实现审核逻辑
      console.log('Reviewing project:', project);
	},
    getStatusClass(projectOutput) {
      if (projectOutput === '已发布') {
        return 'released';
      } else if (projectOutput === '未发布') {
        return 'not-released';
      }
    },
	 mounted() {
		this.fetchProjects(); // 组件加载时获取项目数据
	}
	}
};
</script>


<style scoped>
.container {
  max-width: 360px;
  margin: 0 auto;
  padding: 20px;
}

.top-box {
  background-color: #F1F3F9;
  padding: 10px;
  margin-bottom: 20px;
  display: flex;
  justify-content: center;
  border-radius: 10px;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 150px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content.show {
  display: block;
}

.dropdown-content a {
  color: black;
  padding: 10px 10px;
  text-decoration: none;
  display: block;
}

.dropbtn {
  background-color: #5363E3;
  color: white;
  padding: 0.5px 40px;
  font-size: 18px;
  border: none;
  cursor: pointer;
}

.button-group {
  display: flex;
  gap: 30px; /* 设置按钮之间的间距为30px */
}

.dropdown {
  position: relative;
  display: inline-block;
}

.button-group{
  place-items: center;
  font-size: 18px;
}


.project-list {
  font-size: 15px;
  display: flex;
  flex-direction: column;
}

.project-box {
  background-color: #EDEFFE;
  padding: 10px;
  margin-bottom: 10px;
  display: flex;
  align-items: center;
  border-radius: 10px;
}

.project-icon {
  width: 30px;
  height: 30px;
  margin-right: 10px;
}

.project-info {
  flex: 1;
}

.buttons {
  align-items: center;
}

.buttons button {
  font-size: 15px;
  width: 60px;
  background-color: #ffffff;
  margin-top: 5px; /* 上侧间距 */
  margin-bottom: 5px; /* 下侧间距 */
}

/* 修改项目状态颜色 */
.project-output.released {
  color: #45B675;
}

.project-output.not-released {
  color: #54A1FF;
}
</style>











