<template>
	<view  class="beijing"> 
	<!-- 大背景 -->
	<view style="height: 30rpx;">
	</view>
		<view class="dakuang" >
			<view class="zidingyi">
					<text class="mingcheng">{{ projectData.projectName }}</text>
			</view>
			<view class="neirong">
				<view class="jiben">
					<text>基本信息</text>
				</view>
				<view v-for="(item, key) in projectData" :key="key" class="xiu-nei">
				    <text class="wenben">{{ getLabel(key) }}</text>
				    <text class="ziliao">{{ item }}</text>
				  </view>
			</view>
		</view>
		<view class="bottom-box" >
			<button class="queren" @click="confirmUpload">确认发布</button>
			<uni-popup ref="popup" type="center" background-color="#fff" :animation="false" borderRadius="40rpx" v-show="showPopup">
				<view class="tanchuang">
					{{ popupMessage }}
				</view>
				<view class="tanchu" @tap="closePopup">
					确认
				</view>
			</uni-popup>
		</view>
	</view>
</template>

<script>
	
import axios from 'axios';
	
	export default {
		data() {
			return {
				showPopup: false,
				popupMessage: '',
				projectData: {
					// projectName: '项目名称',
					// projectType: '项目类型',
					// projectCeo: '项目负责人',
					// projectContent: '项目内容',
					// projectAllmoney: '项目总投入',
					// projectWorktime: '项目工期',
					// projectWokerPrice: '项目报价',
					// projectFinancing: '项目融资金额'
				} 
			};
		},
		created() {
		    // 模拟从后台获取数据
		    this.getProjectData();
		  },
		methods: {
			getLabel(key) {
			  // 根据 key 返回对应的文本
			  const labels = {
				projectName: '项目名称',
				projectType: '项目类型',
				projectCeo: '项目负责人',
				projectContent: '项目内容',
				projectAllmoney: '项目总投入',
				projectWorktime: '项目工期',
				projectWokerPrice: '项目报价',
				projectFinancing: '项目融资金额'
			  };
			  return labels[key];
			},
			getProjectData() {
			      // 模拟后台数据
			    this.projectData = {
					projectName: '绿色能源创新',
			        projectType: '设计类',
			        projectCeo: '廖嘉琪',
			        projectContent: '绿色能源创新项目优化能源结构，推动可持续发展，减少环境污染。',
			        projectAllmoney: '8500万',
			        projectWorktime: '10个月',
			        projectWokerPrice: '4735万',
			        projectFinancing: '1亿',
					// projectOutput: 0      // this.projectOutput
			      };
			    },
			confirmUpload() {
				this.$refs.popup.open('center');
				this.showPopup = true;
				this.popupMessage = '发布成功！';
				this.projectOutput = 1;
			},
		    closePopup() {
				// 关闭弹窗
				this.showPopup = false;
		      },

		}
	}
</script>

<style scoped>
.jiben{
	margin-left: 40rpx;
	margin-top: 20rpx;
	font-size: 20rpx;
}
.beijing{
	background-color: #ececec;
	width: 100vm;
	height:100vh;
}
.xiu-ti{
	font-size: 30rpx;
	margin-left: 40rpx;
},
.xuanze{
	font-size: 23rpx;
	margin-left: 30rpx;
	color: #ccc;
	// font-family: ;
}
.dakuang{
	background-color: white;
	width: 700rpx;
	height:900rpx;
	border-radius: 10rpx; 
	margin: auto;
	border: 1rpx
	solid #e6e6e6;
	align-items: center;
}
.zidingyi{
	background-color: #52a6ff; 
    border-top-left-radius: 10rpx;
    border-top-right-radius: 10rpx;
	width: 700rpx;
	height:100rpx;
	display: flex;
	position: relative;
	justify-content: center;

}
.mingcheng{
	font-size: 35rpx;
	color: #fff;
	/* font-weight: bold; */
	align-self: center;
}
.xiu-nei{
	font-size: 20rpx;
	margin-top: 50rpx;
	margin-left: 40rpx;
	margin-right: 40rpx;
	display: flex;
	justify-content: space-between; /* 在项目之间均匀分布空间 */
	align-items: center;
/* 	border-bottom:1px solid #e6e6e6; */
}
.wenben{
	text-align: left;
	color: #b4b4b4;
	font-weight: bold;
}
.neirong{
	
}

.bottom-box {
	background-color:  #52a6ff;
	height: 125rpx;
	width: 100vm; 
	position: fixed;
	bottom: 0;
	
}
.queren{
	height: 125rpx;
	width: 100vw; 
	font-size: 35rpx;
	font-weight: bold;
	color: #fff;
	background-color: #52a6ff;
	text-align: center;
    display: flex;
	justify-content: center;
	align-items: center;
}
.tanchuang{
	width: 425rpx; 
	height: 230rpx;
	border-radius: 40rpx; 
	text-align: center; 
	background-color: white;
    display: flex;
	justify-content: center;
	align-items: center;
	margin: auto;
}
.tanchu{
	height: 80rpx;
    display: flex;
	margin: auto;
    border-bottom-left-radius: 40rpx;
    border-bottom-right-radius: 40rpx;
	align-items: center;
	justify-content: center;
	border-top: 1px solid #e6e6e6;
	background-color: #52a6ff ;
	color: white;
}
.ziliao{
	text-align: right;
	color: #666666;
	font-weight: bold;
}
</style>
