<template>
<view class="beijing">
		<view style="background-color: white; height: 800rpx; margin-top: 10px;">
			<text class="tianjia">添加附件</text>
			<view style="margin-bottom: 20rpx;">
				<text class="tupiangeshi">图片格式支持：jpg，png，jpeg</text>
			</view>
			<view class="dakuang" >
				<!-- label="自定义上传图标+指定上传按钮宽高" -->
				<view class="zidingyi">
					<text class="tupian">图片上传</text>
					<view class="item"  @tap="chooseImage">
						<uni-icons type="plus-filled" size="26" color="#fff"></uni-icons>
					</view>
				</view>
				<view class="shangchuan">
					 <image v-if="projectdoinqpaper_url" :src="projectdoinqpaper_url" mode="aspectFill" class="uploaded-img" />
				</view>
			</view>
			<view class="inputs">
				<view class="input-group">
						<text class="label" style="margin-right: 70rpx;">上传人</text>
						<span>
							<input class="input" v-model="paper_user" placeholder="   请输入上传人姓名"  />
						</span>
			    </view>
		
				<view class="input-group">
					<text class="label">上传时间</text>
					<span>
						<input class="input" v-model="paper_time" placeholder="   请选择或输入上传时间" />
					</span>
				</view>
			</view>
			<view class="bottom-box" >
				<button class="queren" @click="confirmUpload">确认上传</button>
				<uni-popup ref="popup" type="center" background-color="#fff" :animation="false" borderRadius="40rpx" v-show="showPopup">
					<view class="tanchuang">
						{{ popupMessage }}
					</view>
					<view class="tanchu" @tap="closePopup">
						确认
					</view>
				</uni-popup>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				// // 上传图片域名 
				projectdoinqpaper_url: '',
		        paper_user: '', // 上传人
		        paper_time: '', // 上传时间
		        projectdoinapaper_id: '', // 图片ID
				showPopup: false, // 控制弹窗的显示
				};
		},
		
		methods: {
			confirmUpload() {
			    // 检查数据是否齐全
			    if (
			        this.projectdoinqpaper_url &&
			        this.paper_user &&
			        this.paper_time &&
			        this.projectdoinapaper_id
			    ) {
			        // 数据齐全，模拟发送数据到后台的操作（这里用 console.log 模拟）
			        const formData = {
			            projectdoinapaper_id: this.projectdoinapaper_id,
			            projectdoinqpaper_url: this.projectdoinqpaper_url,
			            paper_user: this.paper_user,
			            paper_time: this.paper_time,
			        };
			        console.log('上传数据到后台:', formData);
			
			        // 显示上传成功的弹窗，并清空数据
			        this.showPopup = true;
			        this.$refs.popup.open('center');
					this.popupMessage = '上传成功！'
			
			        // 清空数据
			        this.projectdoinqpaper_url = '';
			        this.paper_user = '';
			        this.paper_time = '';
			        this.projectdoinapaper_id = '';
			    } else {
					this.showPopup = true;
					this.$refs.popup.open('center');
					this.popupMessage = '上传失败，数据不完整！'
			        // 数据不完整，弹出上传失败的弹窗
			    }
			},
		    closePopup() {
				// 关闭弹窗并清空数据
				this.showPopup = false;
		        this.projectdoinqpaper_url = '';
		        this.paper_user = '';
		        this.paper_time = '';
		      },
		  // 点击加号图标选择图片
		    chooseImage() {
		      uni.chooseImage({
		        count: 1, // 最多选择一张图片
		        sizeType: ['compressed'], // 压缩图片
		        sourceType: ['album'], // 从相册选择
		        success: (res) => {
					// 假设这里是获取图片ID的逻辑，可以根据实际情况修改
					this.projectdoinapaper_id = '123'; // 假设将ID设置为固定值'123'
					this.projectdoinqpaper_url = res.tempFilePaths[0]; // 将选择的图片地址保存到 imageUrl
		        },
		      });
		    },
		}
	}
</script>

<style scoped>
.tupiangeshi{
	font-size: 23rpx;
	margin-left: 30rpx;
	color: #ccc;
	// font-family: ;
}

.tianjia{
	font-size: 30rpx;
	margin-left: 40rpx;
},
.beijing{
	background-color: #e6e6e6;
	width: 100%;
	height:2000rpx ;
},
/* .s-add-list-btn-icon {s
    font-size: 80rpx;
    height: 80rpx;
    line-height: 80rpx;
    margin-bottom: 20rpx;
    color: #999;
} */
.tupian{
	align-self: center;
	font-size: 30rpx;
	margin-left: 50rpx;
	color: #fff;
	font-weight: bold;
},
.dakuang{
	width: 680rpx;
	height:400rpx;
	border-radius: 20rpx; 
	margin: auto;
	border: 1rpx
	solid #e6e6e6;
	align-items: center;
}
.zidingyi{
	background-color: #52a6ff; 
	/* margin: 15px; */
    border-top-left-radius: 20rpx;
    border-top-right-radius: 20rpx;
	width: 680rpx;
	height:100rpx;
	display: flex;
	position: relative;
	justify-content: space-between; 

},
.shangchuan{
	border: 10rpx;
	margin: 15rpx;
	height:280rpx;
	border: 1rpx ;
	display: flex;
	solid: #e6e6e6;
}
.add-icon {
    font-size: 16rpx; /* Adjust the icon size */
}
.upload-icon{
	position: absolute;
	right: 10rpx; 
	font-size: 16rpx;
	color: #fff; 
}
.item{
	margin-right: 20rpx;
	align-self: center;
	color: #fff;
}
.bottom-box {
    background-color: #52a6ff;
	height: 125rpx;
	width: 100vw; 
	position: fixed;
	bottom: 0;
	
}
.queren{
	height: 125rpx;
	width: 100vw; 
	font-size: 30rpx;
	font-weight: bold;
	color: #fff;
	background-color: #52a6ff;
	text-align: center;
    display: flex;
	justify-content: center;
	align-items: center;

}
.tanchuang{
	width: 425rpx; 
	height: 230rpx;
	border-radius: 40rpx; 
	text-align: center; 
	background-color: white;
    display: flex;
	justify-content: center;
	align-items: center;
	margin: auto;
}
.tanchu{
	height: 80rpx;
    display: flex;
	margin: auto;
	align-items: center;
	justify-content: center;
	border-top: 1px solid #e6e6e6;
}
.uploaded-img {
  width: 100%;
  height: 100%;
  border-radius: 20rpx;
}
.input-group {
  margin-bottom: 20rpx;
  display: flex;
  align-items: center;
}

.label {
	margin-left: 60rpx;
	margin-right: 40rpx;
  	margin-top: 30rpx;
	font-size: 28rpx;
	color: #333;
}
.input {
	width: 400rpx;
	height: 60rpx;
	margin-top: 30rpx;
	font-size: 28rpx;
	border: 1px solid #ececec;
	border-radius: 10rpx;
}
</style>
