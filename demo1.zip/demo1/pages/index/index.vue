<template>

</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},

		methods: {

		}
	}
</script>

<style lang="scss">

.box{

	height: 100px;
	background: pink;
	h3{
		font-size: 50px;
		.row{
			// 倾斜
			font-style: italic;
			color: rebeccapurple;
		}
	}
}


</style>
